/*
 * Frame buffer position and size:
 */
extern unsigned long sgivwfb_mem_phys;
extern unsigned long sgivwfb_mem_size;
