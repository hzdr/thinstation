#ifndef _ASM_X86_APIC_FLAT_64_H
#define _ASM_X86_APIC_FLAT_64_H

extern void flat_init_apic_ldr(void);

#endif

