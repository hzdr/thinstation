MODIFIED
--------

Internal management property.  Do not set or get.

This is an internal cache entry property managed by CMake to track
interactive user modification of entries.  Ignore it.
