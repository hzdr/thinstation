FIND_LIBRARY_USE_LIB64_PATHS
----------------------------

Whether FIND_LIBRARY should automatically search lib64 directories.

FIND_LIBRARY_USE_LIB64_PATHS is a boolean specifying whether the
FIND_LIBRARY command should automatically search the lib64 variant of
directories called lib in the search path when building 64-bit
binaries.
