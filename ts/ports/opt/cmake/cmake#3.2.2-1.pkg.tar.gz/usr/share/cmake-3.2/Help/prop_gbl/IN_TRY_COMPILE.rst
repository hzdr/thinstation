IN_TRY_COMPILE
--------------

Read-only property that is true during a try-compile configuration.

True when building a project inside a TRY_COMPILE or TRY_RUN command.
