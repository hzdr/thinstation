ARCHIVE_OUTPUT_NAME_<CONFIG>
----------------------------

Per-configuration output name for ARCHIVE target files.

This is the configuration-specific version of ARCHIVE_OUTPUT_NAME.
