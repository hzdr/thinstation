RUNTIME_OUTPUT_DIRECTORY
------------------------

.. |XXX| replace:: RUNTIME
.. |xxx| replace:: runtime
.. |CMAKE_XXX_OUTPUT_DIRECTORY| replace:: CMAKE_RUNTIME_OUTPUT_DIRECTORY
.. include:: XXX_OUTPUT_DIRECTORY.txt
