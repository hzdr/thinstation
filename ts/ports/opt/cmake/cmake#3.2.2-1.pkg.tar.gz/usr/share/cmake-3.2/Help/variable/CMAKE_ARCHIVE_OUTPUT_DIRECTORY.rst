CMAKE_ARCHIVE_OUTPUT_DIRECTORY
------------------------------

Where to put all the ARCHIVE targets when built.

This variable is used to initialize the ARCHIVE_OUTPUT_DIRECTORY
property on all the targets.  See that target property for additional
information.
