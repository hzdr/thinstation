CMAKE_FIND_ROOT_PATH_MODE_PROGRAM
---------------------------------

.. |FIND_XXX| replace:: :command:`find_program`

.. include:: CMAKE_FIND_ROOT_PATH_MODE_XXX.txt
