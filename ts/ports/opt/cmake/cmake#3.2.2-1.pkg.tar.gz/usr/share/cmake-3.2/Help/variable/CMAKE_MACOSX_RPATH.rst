CMAKE_MACOSX_RPATH
-------------------

Whether to use rpaths on Mac OS X.

This variable is used to initialize the :prop_tgt:`MACOSX_RPATH` property on
all targets.
