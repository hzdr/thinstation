CMAKE_POSITION_INDEPENDENT_CODE
-------------------------------

Default value for POSITION_INDEPENDENT_CODE of targets.

This variable is used to initialize the POSITION_INDEPENDENT_CODE
property on all the targets.  See that target property for additional
information.
