CMAKE_VS_MSDEV_COMMAND
----------------------

The :generator:`Visual Studio 6` generator sets this variable to the
``msdev.exe`` command installed with Visual Studio 6.

This variable is not defined by other generators even if ``msdev.exe``
is installed on the computer.

See also the :variable:`CMAKE_MAKE_PROGRAM` variable.
