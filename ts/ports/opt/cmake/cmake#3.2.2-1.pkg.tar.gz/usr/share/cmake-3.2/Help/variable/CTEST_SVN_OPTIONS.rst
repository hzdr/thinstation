CTEST_SVN_OPTIONS
-----------------

Specify the CTest ``SVNOptions`` setting
in a :manual:`ctest(1)` dashboard client script.
