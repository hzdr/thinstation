MSVC71
------

True when using Microsoft Visual C 7.1

Set to true when the compiler is version 7.1 of Microsoft Visual C.
